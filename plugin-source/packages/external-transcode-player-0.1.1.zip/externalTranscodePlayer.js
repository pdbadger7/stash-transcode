"use strict";
(() => {
  // src/runtime.ts
  var pluginApi = window.PluginApi;
  var PluginApi = pluginApi;
  var React = pluginApi.React;

  // src/stashApi.ts
  function buildPlaybackUrl(baseUrl, pathPattern, sceneId, token, quality) {
    const url = new URL(baseUrl);
    const path = pathPattern.replace("{id}", sceneId);
    url.pathname = path;
    if (token) {
      url.searchParams.set("token", token);
    }
    if (quality && quality !== "auto") {
      url.searchParams.set("quality", quality);
    }
    return url.toString();
  }
  async function probeExternalAgent(baseUrl, sceneId, token, signal) {
    try {
      const url = new URL(baseUrl);
      url.pathname = `/stash/scene/${sceneId}/probe`;
      if (token) {
        url.searchParams.set("token", token);
      }
      const response = await fetch(url.toString(), {
        method: "GET",
        credentials: "include",
        signal
      });
      if (!response.ok) {
        return {
          ok: false,
          error: `HTTP ${response.status}`
        };
      }
      const data = await response.json();
      return data;
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : "Probe failed"
      };
    }
  }
  function hasHlsJs() {
    return getHlsConstructor() !== void 0;
  }
  function getHlsConstructor() {
    return window.Hls;
  }
  function hasNativeHls() {
    const video = document.createElement("video");
    const canPlay = video.canPlayType("application/vnd.apple.mpegurl");
    return canPlay === "maybe" || canPlay === "probably";
  }

  // src/types.ts
  var PLAYBACK_QUALITIES = [
    { id: "auto", label: "Auto" },
    { id: "1080p", label: "1080p" },
    { id: "720p", label: "720p" },
    { id: "480p", label: "480p" }
  ];

  // src/ExternalVideoPlayer.tsx
  var { useRef, useEffect, useState } = React;
  var ExternalVideoPlayer = ({
    url,
    mode,
    title,
    debug = false,
    selectedQuality,
    onQualityChange,
    onError
  }) => {
    const videoRef = useRef(null);
    const [error, setError] = useState(null);
    useEffect(() => {
      if (debug) {
        console.log("[ExternalVideoPlayer] Rendering", {
          url,
          mode,
          hasHlsJs: hasHlsJs(),
          hasNativeHls: hasNativeHls()
        });
      }
    }, [url, mode, debug]);
    useEffect(() => {
      const video = videoRef.current;
      if (!video) return;
      setError(null);
      let hlsInstance = null;
      if (mode === "hls") {
        if (hasNativeHls()) {
          if (debug) console.log("[ExternalVideoPlayer] Using native HLS");
          video.src = url;
        } else if (hasHlsJs()) {
          if (debug) console.log("[ExternalVideoPlayer] Using hls.js");
          const Hls = getHlsConstructor();
          if (!Hls) {
            const msg = "HLS support not available";
            console.warn("[ExternalVideoPlayer]", msg);
            setError(msg);
            onError?.(new Error(msg));
            return;
          }
          hlsInstance = new Hls();
          hlsInstance.attachMedia(video);
          hlsInstance.on("hlsError", (_, data) => {
            console.error("[ExternalVideoPlayer] HLS error:", data);
            setError(`HLS Error: ${data.type}`);
            onError?.(new Error(`HLS Error: ${data.type}`));
          });
          hlsInstance.loadSource(url);
        } else {
          const msg = "HLS support not available";
          console.warn("[ExternalVideoPlayer]", msg);
          setError(msg);
          onError?.(new Error(msg));
        }
      } else {
        if (debug) console.log("[ExternalVideoPlayer] Direct playback");
        video.src = url;
      }
      return () => {
        hlsInstance?.destroy?.();
        video.removeAttribute("src");
        video.load();
      };
    }, [url, mode, debug, onError]);
    return /* @__PURE__ */ React.createElement("div", { style: { width: "100%", height: "100%", position: "relative" } }, mode === "hls" && onQualityChange ? /* @__PURE__ */ React.createElement(
      "div",
      {
        style: {
          position: "absolute",
          top: "0.75rem",
          right: "0.75rem",
          zIndex: 2,
          background: "rgba(0, 0, 0, 0.75)",
          color: "#fff",
          padding: "0.5rem",
          borderRadius: "0.35rem"
        }
      },
      /* @__PURE__ */ React.createElement("label", { style: { display: "flex", gap: "0.5rem", alignItems: "center" } }, /* @__PURE__ */ React.createElement("span", { style: { fontSize: "0.8rem" } }, "Quality"), /* @__PURE__ */ React.createElement(
        "select",
        {
          value: selectedQuality,
          onChange: (event) => onQualityChange(event.target.value)
        },
        PLAYBACK_QUALITIES.map((quality) => /* @__PURE__ */ React.createElement("option", { key: quality.id, value: quality.id }, quality.label))
      ))
    ) : null, error ? /* @__PURE__ */ React.createElement(
      "div",
      {
        style: {
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#000",
          color: "#fff",
          padding: "1rem",
          textAlign: "center"
        }
      },
      /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", null, "Playback Error"), /* @__PURE__ */ React.createElement("p", { style: { fontSize: "0.9rem", color: "#ccc" } }, error))
    ) : /* @__PURE__ */ React.createElement(
      "video",
      {
        ref: videoRef,
        style: {
          width: "100%",
          height: "100%",
          display: "block"
        },
        controls: true,
        playsInline: true,
        preload: "metadata",
        title
      }
    ));
  };

  // src/externalTranscodePlayer.tsx
  var { useState: useState2, useEffect: useEffect2, useMemo } = React;
  var DEFAULT_SETTINGS = {
    externalTranscodeBaseUrl: "https://video.home",
    playbackMode: "direct",
    directPathPattern: "/stash/scene/{id}/direct",
    hlsPathPattern: "/stash/scene/{id}/master.m3u8",
    probeBeforeReplace: true,
    fallbackToStashPlayer: true,
    sharedToken: "",
    debug: false
  };
  function normalizeSettings(settings) {
    return {
      ...DEFAULT_SETTINGS,
      ...settings,
      playbackMode: settings?.playbackMode === "hls" ? "hls" : "direct"
    };
  }
  var ScenePlayerPatch = ({
    scene,
    originalComponent: OriginalPlayer,
    settings
  }) => {
    const resolvedSettings = useMemo(() => normalizeSettings(settings), [settings]);
    const [useExternal, setUseExternal] = useState2(false);
    const [error, setError] = useState2(null);
    const [playbackUrl, setPlaybackUrl] = useState2(null);
    const [quality, setQuality] = useState2("auto");
    useEffect2(() => {
      setQuality("auto");
    }, [scene?.id]);
    if (resolvedSettings.debug) {
      console.log("[ScenePlayerPatch] Rendering with scene:", scene?.id);
    }
    useEffect2(() => {
      const controller = new AbortController();
      let cancelled = false;
      if (!scene?.id) {
        if (resolvedSettings.debug) console.log("[ScenePlayerPatch] No scene ID");
        setUseExternal(false);
        return () => {
          cancelled = true;
          controller.abort();
        };
      }
      const initializeExternalPlayer = async () => {
        try {
          if (resolvedSettings.probeBeforeReplace) {
            if (resolvedSettings.debug)
              console.log(`[ScenePlayerPatch] Probing scene ${scene.id}`);
            const probeResult = await probeExternalAgent(
              resolvedSettings.externalTranscodeBaseUrl,
              scene.id,
              resolvedSettings.sharedToken,
              controller.signal
            );
            if (cancelled) {
              return;
            }
            if (!probeResult.ok) {
              if (resolvedSettings.debug)
                console.log("[ScenePlayerPatch] Probe failed:", probeResult.error);
              if (resolvedSettings.fallbackToStashPlayer) {
                setUseExternal(false);
                setError(null);
                return;
              }
              setError(probeResult.error || "Probe failed");
              setUseExternal(false);
              return;
            }
          }
          const pathPattern = resolvedSettings.playbackMode === "hls" ? resolvedSettings.hlsPathPattern : resolvedSettings.directPathPattern;
          const url = buildPlaybackUrl(
            resolvedSettings.externalTranscodeBaseUrl,
            pathPattern,
            scene.id,
            resolvedSettings.sharedToken,
            quality
          );
          if (cancelled) {
            return;
          }
          if (resolvedSettings.debug)
            console.log("[ScenePlayerPatch] Using external player:", url);
          setPlaybackUrl(url);
          setUseExternal(true);
          setError(null);
        } catch (err) {
          if (cancelled) {
            return;
          }
          const message = err instanceof Error ? err.message : "Unknown error";
          console.error("[ScenePlayerPatch] Error:", message);
          if (resolvedSettings.fallbackToStashPlayer) {
            setUseExternal(false);
            setError(null);
          } else {
            setError(message);
            setUseExternal(false);
          }
        }
      };
      initializeExternalPlayer();
      return () => {
        cancelled = true;
        controller.abort();
      };
    }, [scene?.id, quality, resolvedSettings]);
    const handlePlaybackError = (err) => {
      console.error("[ScenePlayerPatch] Playback error:", err.message);
      if (resolvedSettings.fallbackToStashPlayer) {
        if (resolvedSettings.debug)
          console.log("[ScenePlayerPatch] Falling back to original player");
        setUseExternal(false);
        setError(null);
      } else {
        setError(err.message);
      }
    };
    if (error && !resolvedSettings.fallbackToStashPlayer) {
      return /* @__PURE__ */ React.createElement(
        "div",
        {
          style: {
            width: "100%",
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "#000",
            color: "#fff",
            padding: "1rem"
          }
        },
        /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("p", null, "External playback error"), /* @__PURE__ */ React.createElement("p", { style: { fontSize: "0.9rem", color: "#ccc" } }, error))
      );
    }
    if (useExternal && playbackUrl) {
      return /* @__PURE__ */ React.createElement(
        ExternalVideoPlayer,
        {
          url: playbackUrl,
          mode: resolvedSettings.playbackMode,
          title: scene?.title,
          debug: resolvedSettings.debug,
          selectedQuality: quality,
          onQualityChange: setQuality,
          onError: handlePlaybackError
        }
      );
    }
    if (resolvedSettings.debug) console.log("[ScenePlayerPatch] Using original player");
    return React.createElement(OriginalPlayer);
  };

  // src/index.ts
  var defaultSettings = {
    externalTranscodeBaseUrl: "https://video.home",
    playbackMode: "direct",
    directPathPattern: "/stash/scene/{id}/direct",
    hlsPathPattern: "/stash/scene/{id}/master.m3u8",
    probeBeforeReplace: true,
    fallbackToStashPlayer: true,
    sharedToken: "",
    debug: false
  };
  function normalizeSettings2(settings) {
    return {
      ...defaultSettings,
      ...settings,
      playbackMode: settings?.playbackMode === "hls" ? "hls" : "direct"
    };
  }
  PluginApi.patch.instead(
    "ScenePlayer",
    function(props, _, original) {
      return React.createElement(ScenePlayerPatch, {
        scene: props?.scene,
        originalComponent: original,
        settings: normalizeSettings2(props?.settings ?? props?.pluginSettings)
      });
    }
  );
})();
